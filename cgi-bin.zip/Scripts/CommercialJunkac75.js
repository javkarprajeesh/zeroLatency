﻿var enquiry = EnquiryForm('EnquiryForm', { completeUrl: completeUrl });

function submitEnquiry(token) {
    enquiry.submitForm(token);
};