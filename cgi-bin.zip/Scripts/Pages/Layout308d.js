
$(document).ready(function(){
  $(".base-footer").load("footer.html");
  $(".includeheader").load("header.html");
});